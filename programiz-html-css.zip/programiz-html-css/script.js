document.getElementById('cardButton').addEventListener('click', function() {
    alert('Button clicked!');
});
